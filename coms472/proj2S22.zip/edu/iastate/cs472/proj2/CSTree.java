package edu.iastate.cs472.proj2; 

public class CSTree<E> 
{
	CSNode<E> root;
	int size;
}
